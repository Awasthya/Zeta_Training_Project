package com.zeta.controller;

import java.util.List;

import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.zeta.model.Loan;
import com.zeta.service.BankService;


@RestController
public class LoanController {

	//  AutoWired BankService 
	@Autowired
	BankService bankService;
	
	public static Logger LOG = Logger.getLogger(LoanController.class);
	
	
	// This block of Code is used for getting all data from database
	@RequestMapping(value="/getloandetail/all",method=RequestMethod.GET)
	public List<Loan> getLoanDetail(){
		BasicConfigurator.configure();
		LOG.info("API for getting all data is called ");
		return bankService.getAllLoan();
	}
	
	
	// This block of code is used for add new customer in database
	@PostMapping(value="/addloandetail")
	public Loan postLoanDetail(@RequestBody Loan loanDetail){
		
		LOG.info("API for posting loan detail  ");
		
		 return bankService.addLoanDetail(loanDetail);
	}
	
	// This block of code is used for deleting all Loan Detail
	@DeleteMapping(value="/deleteloandetail/all")
	public void deleteLoanDetail(){
		BasicConfigurator.configure();
		LOG.info("API for deleting all data is called ");
		 bankService.deleteAllLoan();
	}
	
	// This block of code is used for deleting loan detail based on Id
	@RequestMapping(value="/deleteLoanDetail/{id}", method= RequestMethod.DELETE)
	public  void deleteLoanDetailById(@PathVariable int id){
		BasicConfigurator.configure();
		LOG.info("API for deleting data by id is called ");
		 bankService.deleteLoanById(id);
		 
	}
	
	
	// This block of code is used for getting loan detail based on Id
	@RequestMapping(value="/getloandetail/{id}",method=RequestMethod.GET)
	public Loan getLoanDetailByID(@PathVariable int id){
		BasicConfigurator.configure();
		LOG.info("API for getting data by id is called ");
		return bankService.getLoanById(id);
	}
	
	
}
