package com.zeta.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

import com.zeta.model.Loan;
import com.zeta.repository.BankRepository;

@Service
public class BankService {

	@Autowired 
	BankRepository bankrepo;
	
	// called by /getloandetail/all 
	public List<Loan> getAllLoan(){
		List bankLoan = new ArrayList();
		
		// adding loan into bankLoan variable;
		bankrepo.findAll().forEach(loan -> bankLoan.add(loan));
		
		return bankLoan;
	}
	
	// This function is called by "/getloandetail/{id}"  
	public Loan getLoanById(int loanId){
		return bankrepo.findOne(loanId);
	}
	
	// This function is called by post method "/addloandetail 
	public Loan addLoanDetail(Loan loan){
		System.out.print(loan);
		return bankrepo.save(loan);
	}
	
	// this is used for put method '/
	public void updateLoanDetail(Loan loan){
		bankrepo.save(loan);
	}
	
	public void deleteAllLoan(){
		
	}
	public void deleteLoanById(int id){

		bankrepo.delete(id);
	}
}
