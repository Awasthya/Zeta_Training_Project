package com.zeta.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="loan")
public class Loan {
	// loan_no is primary key auto increment
	@Id
	@Column
	int loan_no;
	@Column
	String aadhar_no;
	@Column
	String first_name;
	@Column
	String last_name;
	@Column
	int loan_amount;
	@Column
	String loan_start_date;
	// Tenure represent duration of loan
	@Column
	String tenure;
	
	public Loan(){
		
	}
	
	// This constructor is used for assigning loan for first Time
	public Loan(int loan_no, String aadhar_no, String first_name, String last_name, int loan_amount,
			String loan_start_date, String tenure) {
		super();
		this.loan_no = loan_no;
		this.aadhar_no = aadhar_no;
		this.first_name = first_name;
		this.last_name = last_name;
		this.loan_amount = loan_amount;
		this.loan_start_date = loan_start_date;
		this.tenure = tenure;
	}
	
	// Getters & Setters
	public int getLoadNo() {
		return loan_no;
	}
	public void setLoadNo(int loadNo) {
		this.loan_no = loadNo;
	}
	public String getAadharNo() {
		return aadhar_no;
	}
	public void setAadharNo(String aadharNo) {
		aadhar_no = aadharNo;
	}
	public String getFullName() {
		return first_name;
	}
	public void setFullName(String fullName) {
		first_name = fullName;
	}
	public String getLastname() {
		return last_name;
	}
	public void setLastname(String lastname) {
		this.last_name = lastname;
	}
	public int getLoanAmount() {
		return loan_amount;
	}
	public void setLoanAmount(int loanAmount) {
		this.loan_amount = loanAmount;
	}
	public String getLoanStartDate() {
		return loan_start_date;
	}
	public void setLoanStartDate(String loanStartDate) {
		this.loan_start_date = loanStartDate;
	}
	public String getTenure() {
		return tenure;
	}
	public void setTenure(String tenure) {
		this.tenure = tenure;
	}
	
}
