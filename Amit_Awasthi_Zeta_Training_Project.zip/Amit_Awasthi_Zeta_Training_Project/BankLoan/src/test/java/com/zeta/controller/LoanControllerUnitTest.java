package com.zeta.controller;

import static org.junit.Assert.assertEquals;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.Test;
import org.junit.runner.RunWith;


import com.zeta.model.Loan;
import com.zeta.repository.BankRepository;

import junit.framework.Assert;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;


public class LoanControllerUnitTest {

	BankRepository bankRepo;
	@Test
	public void isAccessableTest() throws Exception{
		try{			
			RestTemplate restTemplate = new RestTemplate();
			HttpHeaders headers = new HttpHeaders();
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			headers.add("user-agent",
					"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.99 Safari/537.36");
			HttpEntity<String> entity = new HttpEntity<String>("parameters", headers);

			ResponseEntity response
			= restTemplate.exchange("http://localhost:8080/getloandetail/all", HttpMethod.GET, entity, Object.class);
			Assert.assertNotNull(response);
			Assert.assertEquals(response.getStatusCode(), HttpStatus.OK);
		}catch(Exception err){
			Assert.fail("Fail to run");
		}
	}
	
	@Test
	public void APINotNullTest() throws IOException{
				try {
						RestTemplate restTemplate = new RestTemplate();
						HttpHeaders headers = new HttpHeaders();
						//headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
						headers.add("user-agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.99 Safari/537.36");
						HttpEntity<String> entity = new HttpEntity<String>("parameters", headers);
					
						ResponseEntity response = restTemplate.exchange("http://localhost:8080/getloandetail/all", HttpMethod.GET,entity,Object.class);
						Assert.assertNotNull(response.getBody());
					
						ResponseEntity response1 = restTemplate.exchange("http://localhost:8080/getloandetail/2", HttpMethod.GET,entity,Object.class);
						Assert.assertNotNull(response1.getBody());
					
						ResponseEntity response2 = restTemplate.exchange("http://localhost:8080/deleteLoanDetail/9", HttpMethod.GET,entity,Object.class);
						Assert.assertNotNull(response1.getBody());
				} catch (Exception ex) {
					
						ex.printStackTrace();
						
				}
	}
	
}
