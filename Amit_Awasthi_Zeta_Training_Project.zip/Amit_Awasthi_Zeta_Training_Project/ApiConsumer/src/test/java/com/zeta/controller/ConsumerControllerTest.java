package com.zeta.controller;

import static org.junit.Assert.fail;

import java.util.Arrays;

import org.junit.Test;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.zeta.model.APIModel;
import com.zeta.model.SingleApiModel;

import junit.framework.Assert;


public class ConsumerControllerTest {
	
	@Test
	public void isAccessableTest() throws Exception{
		try{			
			RestTemplate restTemplate = new RestTemplate();
			HttpHeaders headers = new HttpHeaders();
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			headers.add("user-agent",
					"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.99 Safari/537.36");
			HttpEntity<String> entity = new HttpEntity<String>("parameters", headers);

			ResponseEntity<APIModel> response
			= restTemplate.exchange("https://reqres.in/api/users", HttpMethod.GET, entity, APIModel.class);
			Assert.assertEquals(response.getStatusCode(), HttpStatus.OK);
		}catch(Exception err){
			Assert.fail("Fail to run");
		}
	}
	
	@Test
	public void getByIdIsAccessableTest() throws Exception{
		try{			
			RestTemplate restTemplate = new RestTemplate();
			HttpHeaders headers = new HttpHeaders();
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			headers.add("user-agent",
					"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.99 Safari/537.36");
			HttpEntity<String> entity = new HttpEntity<String>("parameters", headers);

			ResponseEntity<SingleApiModel> response
			= restTemplate.exchange("https://reqres.in/api/users/2", HttpMethod.GET, entity, SingleApiModel.class);
			Assert.assertEquals(response.getStatusCode(), HttpStatus.OK);
		}catch(Exception err){
			Assert.fail("Fail to run");
		}
	}
	
	

	}

