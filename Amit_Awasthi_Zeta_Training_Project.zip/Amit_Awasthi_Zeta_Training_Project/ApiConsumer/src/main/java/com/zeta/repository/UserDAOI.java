package com.zeta.repository;

import org.springframework.data.repository.CrudRepository;

import com.zeta.model.User;


public interface UserDAOI extends CrudRepository<User,Integer>{

}
