package com.zeta.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zeta.model.User;
import com.zeta.repository.UserDAOI;

@Service
public class UserService {

	@Autowired
	UserDAOI userDAO;
	public Iterable<User> StoreUserIntoDataBase(List<User> users){
		
		return userDAO.save(users);
		
	}
}
