package com.zeta.model;

import java.util.List;

public class SingleApiModel {

	private User data;
	private Object Support;

	public User getData() {
		return data;
	}

	public void setData(User data) {
		this.data = data;
	}

	public Object getSupport() {
		return Support;
	}

	public void setSupport(Object support) {
		Support = support;
	}

}
