package com.zeta.controller;

import java.util.Arrays;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.zeta.model.APIModel;
import com.zeta.model.SingleApiModel;
import com.zeta.model.User;

@RestController
public class ConsumerController {

	public static Logger LOG = Logger.getLogger(ConsumerController.class);

	// This template is used for getting all data from given URL
	@RequestMapping("/user/all")
	public List<User> getAllUser() {
		ResponseEntity<APIModel> user = null;
		try {
			RestTemplate restTemplate = new RestTemplate();
			HttpHeaders headers = new HttpHeaders();
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			headers.add("user-agent",
					"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.99 Safari/537.36");
			HttpEntity<String> entity = new HttpEntity<String>("parameters", headers);
			LOG.info("This is Api Consumer GetAllUser code access");
			user = restTemplate.exchange("https://reqres.in/api/users", HttpMethod.GET, entity, APIModel.class);

			LOG.info(user.getBody().getData());
		} catch (Exception err) {
			err.printStackTrace();
		}

		return user.getBody().getData();
	}

	// This template is used for getting user Data specificy to user Id.
	@RequestMapping("/user/{id}")
	public User getUserById(@PathVariable int id) {
		ResponseEntity<SingleApiModel> user = null;
		try {
			RestTemplate restTemplate = new RestTemplate();
			HttpHeaders headers = new HttpHeaders();
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			headers.add("user-agent",
					"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.99 Safari/537.36");
			HttpEntity<String> entity = new HttpEntity<String>("parameters", headers);

			user = restTemplate.exchange("https://reqres.in/api/users/" + id, HttpMethod.GET, entity,
					SingleApiModel.class);
			
			LOG.info("For accessing data using id is called");
			LOG.info(user.getBody());
		} catch (Exception err) {
			err.printStackTrace();
		}

		return user.getBody().getData();
	}

	// This method is used for getting full name for given Id
	@RequestMapping("/userFullName/{id}")
	public String getFullNameUserById(@PathVariable int id) {
		ResponseEntity<SingleApiModel> user = null;
		try {
			RestTemplate restTemplate = new RestTemplate();
			HttpHeaders headers = new HttpHeaders();
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			headers.add("user-agent",
					"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.99 Safari/537.36");
			HttpEntity<String> entity = new HttpEntity<String>("parameters", headers);

			user = restTemplate.exchange("https://reqres.in/api/users/" + id, HttpMethod.GET, entity,
					SingleApiModel.class);
			LOG.info("For accessing Full name related to id is called");
		} catch (Exception err) {
			err.printStackTrace();
		}
		User singleUser = user.getBody().getData();
		return singleUser.getFirst_name() + " " + singleUser.getLast_name();
	}
};
